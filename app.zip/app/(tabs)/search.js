// app/(tabs)/search.js
import { useLazyQuery } from "@apollo/client";
import { SearchCardsDocument } from "@sixbyfive/tcg-binder";
import { useRouter } from "expo-router";
import React, { useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  StyleSheet,
  Text,
  View,
} from "react-native";

import EmptyState from "../../components/common/EmptyState";
import CardTile from "../../components/search/CardTile";
import SearchForm from "../../components/search/SearchForm";
import SearchHeader from "../../components/search/SearchHeader";
import { PER_PAGE } from "../../constants/pagination";
import useToast from "../../hooks/useToast";
import { COLORS } from "../../theme/colors";

const NUM_COLUMNS = 2;
const SKELETON_COUNT = 6;

export default function SearchTab() {
  const router = useRouter();
  const toast = useToast();

  // form state
  const [name, setName] = useState("");
  const [setCode, setSetCode] = useState("");
  const [number, setNumber] = useState("");

  // paging state
  const pageRef = useRef(1);
  const loadingMoreRef = useRef(false);
  const [hasMore, setHasMore] = useState(false);

  const isExactCardSearch = useMemo(
    () => Boolean(setCode && number),
    [setCode, number]
  );

  const canSearch = useMemo(
    () =>
      name.trim().length > 0 ||
      setCode.trim().length > 0 ||
      number.trim().length > 0,
    [name, setCode, number]
  );

  const [runSearch, { data, loading, error, fetchMore, called }] = useLazyQuery(
    SearchCardsDocument,
    {
      notifyOnNetworkStatusChange: true,
      fetchPolicy: "network-only",
      nextFetchPolicy: "cache-first",
      returnPartialData: false,
    }
  );

  const results = data?.searchCards?.cards ?? [];

  // Determine if there are more pages, using pageInfo when available.
  const readHasMore = (payload, pageSize) => {
    const root = payload?.searchCards;
    if (!root) return false;
    const pi = root.pageInfo || root.pageinfo || root.pagination || {};
    if (typeof pi.hasMore === "boolean") return pi.hasMore;
    if (typeof pi.hasNextPage === "boolean") return pi.hasNextPage;

    if (pi.total && (pi.page || pi.currentPage)) {
      const page = Number(pi.page ?? pi.currentPage ?? 1);
      const size = Number(pi.pageSize ?? pageSize ?? PER_PAGE);
      return page * size < Number(pi.total);
    }
    const len = (root.cards || []).length;
    return len === (pageSize ?? PER_PAGE) && !isExactCardSearch;
  };

  const onSearch = () => {
    if (!canSearch) return;
    pageRef.current = 1;
    loadingMoreRef.current = false;
    setHasMore(false);

    runSearch({
      variables: {
        input: {
          name: name.trim() || null,
          set: setCode.trim().toUpperCase() || null,
          number: number.trim() || null,
          page: 1,
          pageSize: PER_PAGE,
        },
      },
      onCompleted: (res) => {
        setHasMore(readHasMore(res, PER_PAGE));
      },
    });
  };

  const loadMore = async () => {
    if (!hasMore || loading || loadingMoreRef.current || !called) return;
    loadingMoreRef.current = true;

    const nextPage = pageRef.current + 1;

    try {
      await fetchMore({
        variables: {
          input: {
            name: name.trim() || null,
            set: setCode.trim().toUpperCase() || null,
            number: number.trim() || null,
            page: nextPage,
            pageSize: PER_PAGE,
          },
        },
        updateQuery: (prev, { fetchMoreResult }) => {
          const prevCards = prev?.searchCards?.cards ?? [];
          const nextCards = fetchMoreResult?.searchCards?.cards ?? [];

          // dedupe by id
          const byId = new Map();
          for (const c of [...prevCards, ...nextCards]) {
            if (c?.id != null) byId.set(String(c.id), c);
          }
          const merged = Array.from(byId.values());

          // progress check
          const prevIds = new Set(prevCards.map((c) => String(c?.id)));
          const gotNew = nextCards.some((c) => !prevIds.has(String(c?.id)));
          if (gotNew) pageRef.current = nextPage;

          // hasMore from server first, then heuristic
          const root = fetchMoreResult?.searchCards;
          const pi = root?.pageInfo || root?.pageinfo || root?.pagination || {};
          const nextHasMore =
            typeof pi?.hasMore === "boolean"
              ? pi.hasMore
              : typeof pi?.hasNextPage === "boolean"
              ? pi.hasNextPage
              : nextCards.length === PER_PAGE && !isExactCardSearch;

          setHasMore(gotNew && nextHasMore);

          return { searchCards: { ...(root || {}), cards: merged } };
        },
      });
    } finally {
      loadingMoreRef.current = false;
    }
  };

  // quick actions (stubbed—replace with mutations)
  const handleQuickAdd = async (card) => {
    toast.show(`Added ${card?.name ?? "card"} to collection`, { type: "success" });
  };
  const handleQuickWishlist = async (card) => {
    toast.show(`Saved to wishlist`, { type: "success" });
  };

  // ----- Build display data with skeletons / placeholders -----
  const displayData = useMemo(() => {
    // Show skeletons before first search or while loading
    if (loading || !called) {
      return Array.from({ length: SKELETON_COUNT }, (_, i) => ({
        id: `sk-${i}`,
        __skeleton: true,
      }));
    }
    // After a search, show real results; if none, FlatList will show EmptyState.
    const arr = [...results];
    // Add invisible placeholders to balance last row
    const remainder = arr.length % NUM_COLUMNS;
    if (remainder !== 0) {
      const fillers = NUM_COLUMNS - remainder;
      for (let i = 0; i < fillers; i++) {
        arr.push({ id: `ph-${i}`, __placeholder: true });
      }
    }
    return arr;
  }, [results, loading, called]);

  return (
    <View style={styles.container}>
      <SearchHeader
        title="Pokémon Card Search"
        subtitle="Search for any Pokémon card and add it to your collection"
      />

      <SearchForm
        name={name}
        setName={setName}
        setCode={setCode}
        setSetCode={setSetCode}
        number={number}
        setNumber={setNumber}
        canSearch={canSearch}
        loading={loading}
        onSearch={onSearch}
        errorMessage={error?.message}
      />

      <FlatList
        contentContainerStyle={styles.listContent}
        data={displayData}
        keyExtractor={(item, idx) => (item?.id ? String(item.id) : `${idx}`)}
        numColumns={NUM_COLUMNS}
        columnWrapperStyle={styles.column}
        renderItem={({ item }) => {
          if (item.__skeleton) {
            return <CardTile skeleton />;
          }
          if (item.__placeholder) {
            // Invisible spacer to keep the last row balanced
            return <View style={{ flex: 1, margin: 6 }} />;
          }
          return (
            <CardTile
              item={item}
              onPress={() =>
                router.push({
                  pathname: `/card/${item.id}`,
                  params: {
                    id: String(item.id),
                    name: item.name ?? "",
                    number: String(item.number ?? ""),
                    setName: item.setName ?? "",
                    image: item.image ?? "",
                    prices: JSON.stringify(item.prices ?? []),
                  },
                })
              }
              onQuickAdd={handleQuickAdd}
              onQuickWishlist={handleQuickWishlist}
            />
          );
        }}
        ListEmptyComponent={
          !loading && called ? (
            <EmptyState message="No results found. Try different filters." />
          ) : null
        }
        ListFooterComponent={
          hasMore ? (
            <View style={styles.footerLoading}>
              <ActivityIndicator color={COLORS.accent} />
              <Text style={styles.footerLoadingText}>Loading more…</Text>
            </View>
          ) : null
        }
        onEndReachedThreshold={0.4}
        onEndReached={loadMore}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  listContent: { paddingHorizontal: 6, paddingBottom: 20 },
  column: { gap: 4 },
  footerLoading: {
    paddingVertical: 16,
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },
  footerLoadingText: { color: COLORS.textMuted, fontSize: 12 },
});
