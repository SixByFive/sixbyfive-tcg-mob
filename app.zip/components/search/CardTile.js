// components/search/CardTile.js
import { Ionicons } from "@expo/vector-icons";
import React, { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Animated,
  Image,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { COLORS } from "../../theme/colors";
import { getBestPrice, normalizeImageUrl } from "../../utils/cards";
import AvgPriceBlock from "./AvgPriceBlock";

/**
 * Props:
 *  - item
 *  - onPress
 *  - onQuickAdd?       (async)
 *  - onQuickWishlist?  (async)
 *  - skeleton?: boolean  -> render loading skeleton (no interactions)
 */
export default function CardTile({
  item,
  onPress,
  onQuickAdd,
  onQuickWishlist,
  skeleton = false,
}) {
  if (skeleton) return <SkeletonTile />;

  const price = getBestPrice(item?.prices, "normal");
  const imageUri = normalizeImageUrl(item?.image);

  const [adding, setAdding] = useState(false);
  const [wishing, setWishing] = useState(false);

  const handleAdd = async () => {
    if (!onQuickAdd || adding) return;
    setAdding(true);
    try {
      await onQuickAdd(item);
    } finally {
      setAdding(false);
    }
  };

  const handleWishlist = async () => {
    if (!onQuickWishlist || wishing) return;
    setWishing(true);
    try {
      await onQuickWishlist(item);
    } finally {
      setWishing(false);
    }
  };

  return (
    <View style={styles.card}>
      {/* Image + title area (tap to open) */}
      <Pressable onPress={onPress} style={styles.cardTop} android_ripple={{ color: "#00000022" }}>
        <View style={styles.cardImageWrap}>
          {imageUri ? (
            <Image source={{ uri: imageUri }} style={styles.cardImage} resizeMode="contain" />
          ) : null}
        </View>

        <View style={styles.cardInfo}>
          <Text style={styles.cardName} numberOfLines={1}>
            {item?.name || "—"}
          </Text>

          <View style={styles.rowBetween}>
            <Text style={styles.cardMeta} numberOfLines={1}>
              {item?.setName || "—"}
            </Text>
            <Text style={styles.cardMetaStrong}>#{item?.number ?? "—"}</Text>
          </View>

          <View style={{ marginTop: 8 }}>
            <AvgPriceBlock tcgp={price.tcgplayer} cmkt={price.cardmarket} />
          </View>
        </View>
      </Pressable>

      {/* Quick actions */}
      <View style={styles.actionsRow}>
        <Pressable
          onPress={handleAdd}
          disabled={!onQuickAdd || adding}
          style={({ pressed }) => [
            styles.actionBtn,
            styles.btnPrimary,
            (adding || pressed) && styles.btnPressed,
          ]}
          accessibilityRole="button"
          accessibilityLabel="Add to collection"
        >
          {adding ? (
            <ActivityIndicator size="small" color="#fff" />
          ) : (
            <>
              <Ionicons name="add-circle-outline" size={16} color="#fff" />
              <Text style={styles.btnTextPrimary}>Add</Text>
            </>
          )}
        </Pressable>

        <Pressable
          onPress={handleWishlist}
          disabled={!onQuickWishlist || wishing}
          style={({ pressed }) => [
            styles.actionBtn,
            styles.btnSecondary,
            (wishing || pressed) && styles.btnPressed,
          ]}
          accessibilityRole="button"
          accessibilityLabel="Add to wishlist"
        >
          {wishing ? (
            <ActivityIndicator size="small" color={COLORS.text} />
          ) : (
            <>
              <Ionicons name="heart-outline" size={16} color={COLORS.text} />
              <Text style={styles.btnTextSecondary}>Wishlist</Text>
            </>
          )}
        </Pressable>
      </View>
    </View>
  );
}

/* ---------- Skeleton (animated pulse) ---------- */
function SkeletonTile() {
  const pulse = useRef(new Animated.Value(0.6)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: 800, useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 0.6, duration: 800, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [pulse]);

  return (
    <Animated.View style={[styles.card, { opacity: pulse }]}>
      <View style={styles.cardTop}>
        <View style={styles.cardImageWrap} />
        <View style={styles.cardInfo}>
          <View style={[styles.shimmerLine, { width: "75%" }]} />
          <View style={[styles.rowBetween, { marginTop: 6 }]}>
            <View style={[styles.shimmerLine, { width: "45%", height: 10 }]} />
            <View style={[styles.shimmerLine, { width: 36, height: 10 }]} />
          </View>
          <View style={{ marginTop: 10 }}>
            <View style={[styles.shimmerPill, { width: "100%", height: 26 }]} />
          </View>
        </View>
      </View>

      <View style={styles.actionsRow}>
        <View style={[styles.actionBtn, styles.btnPrimary, styles.shimmerPill]} />
        <View style={[styles.actionBtn, styles.btnSecondary, styles.shimmerPill]} />
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    backgroundColor: COLORS.surface,
    borderColor: COLORS.border,
    borderWidth: StyleSheet.hairlineWidth,
    borderRadius: 16,
    margin: 6,
    overflow: "hidden",
  },

  cardTop: {},

  cardImageWrap: {
    backgroundColor: COLORS.alt,
    aspectRatio: 245 / 337,
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
  },
  cardImage: { ...StyleSheet.absoluteFillObject },

  cardInfo: { padding: 8 },
  cardName: { color: COLORS.text, fontSize: 14.5, fontWeight: "700" },
  rowBetween: {
    marginTop: 4,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  cardMeta: {
    color: COLORS.textMuted,
    fontSize: 12,
    flexShrink: 1,
    marginRight: 8,
  },
  cardMetaStrong: { color: COLORS.text, fontSize: 12, fontWeight: "700" },

  // actions
  actionsRow: {
    flexDirection: "row",
    gap: 8,
    paddingHorizontal: 8,
    paddingBottom: 8,
  },
  actionBtn: {
    flex: 1,
    minHeight: 36,
    borderRadius: 10,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 6,
  },
  btnPressed: { opacity: 0.92, transform: [{ scale: 0.99 }] },

  btnPrimary: { backgroundColor: COLORS.accent, borderColor: COLORS.accent },
  btnSecondary: { backgroundColor: COLORS.background, borderColor: COLORS.border },

  btnTextPrimary: { color: "#fff", fontWeight: "900" },
  btnTextSecondary: { color: COLORS.text, fontWeight: "900" },

  // skeleton bits
  shimmerLine: {
    backgroundColor: COLORS.alt,
    borderRadius: 6,
    height: 12,
  },
  shimmerPill: {
    backgroundColor: COLORS.alt,
    borderColor: COLORS.border,
  },
});
